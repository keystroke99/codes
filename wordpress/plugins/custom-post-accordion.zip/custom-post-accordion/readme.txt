=== Plugin Name ===
Contributors: dakiriki
Donate link: http://geniusworks.xyz/plugins/custom-posts-accordion/
Tags: custom post,accordion, bootstrap
Requires at least: 3.4
Tested up to: 4.8
Stable tag: 4.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin creates Bootstrap accordion form custom posts.

== Description ==

This plugin creates Bootstrap accordion from custom posts.
Requires Bootstrap 3.x, if your theme  is not Bootstrap based you will not be able to use this plugin.
Fully compatible with WPML, just translate your posts and use shortcodes as explained below.
Plugin currently does not support Woocommerce.

== Installation ==


1. Extract downloaded .zip file and upload the extracted folder  to the `/wp-content/plugins` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress - click on "Activate" link below plugin name


== How to use==

1.  To use this plugin you need custom post registerred.
You may check [Post Types](https://codex.wordpress.org/Post_Types "Post Types") to see how to do it.

Example from WP  Codex - for testing, copy and paste  code below to theme functions.php

      add_action( 'init', 'create_post_type' );
      function create_post_type() {
        register_post_type( 'Accordion',
          array(
            'labels' => array(
              'name' => __( 'Accordions' ),
              'singular_name' => __( 'Accordion' )
            ),
            'public' => true,
            'has_archive' => true,
          )
        );
      }

1. Add shortcode to page or post where you want to use accordion

If you used code above to create custom posts type you would use following  shortcode:

    [gw_accordion custom_post="Accordion"]

Optionally, you may add CSS class

    [gw_accordion custom_post="Accordion" class="my_css_class"]

You can also add code to your theme

    <?php echo do_shortcode('[gw_accordion custom_post="Accordion"');?>

or with CSS class

    <?php echo do_shortcode('[gw_accordion custom_post="Accordion" class="my_css_class"]');?>


You also may set ordering , default is by ID and Ascending (ASC)

[gw_accordion custom_post="Accordion" class="my_css_class" order_by="title" order="asc"]


== Demo ==

1. [Check Demo](http://geniusworks.xyz/plugins/custom-posts-accordion/)



== Known Issues ==

If your theme use smooth scroll script like this one

            jQuery(function() {
          jQuery('a[href*="#"]:not([href="#"]').click(function() {
              if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
              var target = jQuery(this.hash);
              target = target.length ? target : jQuery('[name=' + this.hash.slice(1) +']');
              if (target.length) {
                jQuery('html,body').animate({
                  scrollTop: target.offset().top
                }, 2000);
                return false;
              }
            }

          });

        });


You may need to change this line

     jQuery('a[href*="#"]:not([href="#"]')


To look like this

     jQuery('a[href*="#"]:not([href="#"], a:not([data-toggle])')


to avoid conflict


== Frequently Asked Questions ==

Q: Does plugin support Woocommerce?
A: No, not right now.

Q: Can I put images in content to show in accordion?
A: Yes.

Q: Can I use plugin in multilanguage setup?
A: Yes. Plugin is tested and sconfirmed to work with WPML, all you ned to do is to translate your content.

Q: Does plugin support featured images?
A: No, not right now.

== Screenshots ==
Not available.

== Upgrade Notice ==
Not available.

== Changelog ==

= 1.0 =
* Initial release
= 1.0.1 =
* Updated to latest WP and fixed loop reset
