<?php

/**
 * Plugin Name: Custom Posts Accordion
 * Plugin URI: http://geniusworks.xyz
 * Description: This plugin creates Bootstrap accordion from custom posts.
 * Version: 1.0.0
 * Author: Darko Gerguric
 * Author URI: http://geniusworks.xyz
 * License: GPL2
 */

// add our  js script
add_action( 'wp_enqueue_scripts', 'add_gw_accordion_script' );

function add_gw_accordion_script() {
	wp_enqueue_script( 'gw_accordion_script', plugin_dir_url( __FILE__ ) . '/gw_accordion.js', array( 'jquery' ), '1.0', true );
}


// Create  Shortcode
function gw_accordion_generate( $atts ) {

	// Attributes from shortcode
	$atts = shortcode_atts(
		array(
			'custom_post' => 'foo',
      		'class' => '',
			'order_by' => 'ID',
			'order' => 'asc'
			),
			$atts
	);



$accordion=''; // start output
$collapse_count = 1; //start value for counter

	//Define our custom post type name in the arguments

	$args = array('post_type' => esc_attr($atts['custom_post']),'orderby' => esc_attr($atts['order_by']),'order' => esc_attr($atts['order']));

	//Define the loop based on arguments

	$loop = new WP_Query( $args );

	//Display the contents

	 $accordion = "<div class='panel-group ". esc_attr($atts['class'])."' id='accordion'>";

		while ( $loop->have_posts() ) : $loop->the_post();


 			$accordion .=  "<div class='panel panel-default'>
							    <div class='panel-heading'>
								      <h4 class='panel-title'>
								        	<a data-toggle='collapse' data-parent='#accordion' href='#collapse".$collapse_count."' class='collapsed'>".  get_the_title()."</a>
								      </h4>
							    </div>
									<div id='collapse".$collapse_count."' class='panel-collapse collapse '>
									    	<div class='panel-body'>".get_the_content()."</div>
									</div>
							</div>";

			$collapse_count ++;
 			endwhile;wp_reset_query();
			$accordion .="</div>";

			return $accordion;
}
add_shortcode( 'gw_accordion', 'gw_accordion_generate' );
