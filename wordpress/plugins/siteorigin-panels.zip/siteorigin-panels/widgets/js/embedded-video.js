jQuery(function($){
    $('.siteorigin-fitvids').fitVids();
});